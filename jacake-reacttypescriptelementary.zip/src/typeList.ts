/*eslint-disable @typescript-eslint/no-unused-vars*/

/**typescriptの基本の型 */

//boolean
let bool: boolean = true;

//number 数値
let num: number = 0;

//string 文字
let str: string = "A";

//Array 配列
let arr1: Array<number> = [0, 1, 2];
let arr2: number[] = [0, 1, 2];

//tuple 使い道はあまりない、、(笑)
let tuple: [number, string] = [0, "A"];

//any どんな型でも受け入れる=つまり型を指定している意味がない
let any1: any = false;

//void 何も返却値がないことを表す型
//※最悪:voidをつけなくても暗黙的に返却がないからvoidだと推測はする
const funcA = (): void => {
  const test = "TEST";
};

//null
let null1: null = null;

//undefined jsの何も設定されていない状態を表す型
let undefined1: undefined = undefined;

//object
let obj: object = {};
let obj2: {} = {}; //空のobjだとどんな値でも設定可能なので設定する意味がない
let obj3: { id: number; name: string } = { id: 0, name: "kaf" }; //但しこのように空じゃない決め方をするのであればok

//
