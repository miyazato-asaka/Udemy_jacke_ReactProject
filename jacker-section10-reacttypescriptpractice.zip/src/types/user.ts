export type User = {
  name: string;
  hobbies?: Array<string>;
};
